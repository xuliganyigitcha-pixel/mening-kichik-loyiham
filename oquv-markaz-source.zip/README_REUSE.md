# O‘quv Markaz — source archive

This archive contains the pnpm workspace source for the O‘quv Markaz web app, shared API server, database schema, generated API clients, and project configuration.

## Run in a Replit workspace

1. Upload/extract the archive into a fresh Replit workspace.
2. Install dependencies with `pnpm install`.
3. Configure the workspace PostgreSQL database so `DATABASE_URL` is available.
4. Apply the development schema with `pnpm --filter @workspace/db run push`.
5. Start the `artifacts/api-server` and `artifacts/oquv-markaz` workflows.
6. Open the app and create the first super-admin account.

The API contract is `lib/api-spec/openapi.yaml`. After changing it, regenerate client and validation code with `pnpm --filter @workspace/api-spec run codegen`.

Before exposing a new public deployment, protect the first-super-admin setup flow with a one-time setup credential. This archive intentionally contains no secrets or database contents.
