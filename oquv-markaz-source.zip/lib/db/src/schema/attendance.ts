import { createInsertSchema } from "drizzle-zod";
import { integer, pgEnum, pgTable, serial, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { lessonsTable } from "./lessons";
import { studentsTable } from "./students";
import { usersTable } from "./users";

export const attendanceStatusEnum = pgEnum("attendance_status", [
  "present",
  "absent_excused",
  "absent_unexcused",
  "late",
]);

export const attendanceTable = pgTable(
  "attendance",
  {
    id: serial("id").primaryKey(),
    lessonId: integer("lesson_id").notNull().references(() => lessonsTable.id),
    studentId: integer("student_id").notNull().references(() => studentsTable.id),
    status: attendanceStatusEnum("status").notNull(),
    markedBy: integer("marked_by").notNull().references(() => usersTable.id),
    markedAt: timestamp("marked_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("attendance_lesson_student_unique").on(table.lessonId, table.studentId)],
);

export const insertAttendanceSchema = createInsertSchema(attendanceTable).omit({
  id: true,
  markedAt: true,
});
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type AttendanceRecord = typeof attendanceTable.$inferSelect;
