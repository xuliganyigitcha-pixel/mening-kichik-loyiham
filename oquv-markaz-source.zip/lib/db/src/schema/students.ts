import { createInsertSchema } from "drizzle-zod";
import { date, integer, pgEnum, pgTable, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { groupsTable } from "./groups";
import { usersTable } from "./users";

export const studentStatusEnum = pgEnum("student_status", ["active", "finished", "left", "frozen"]);

export const studentsTable = pgTable(
  "students",
  {
    id: serial("id").primaryKey(),
    studentCode: text("student_code").notNull(),
    firstName: text("first_name").notNull(),
    lastName: text("last_name").notNull(),
    phone: text("phone").notNull(),
    address: text("address"),
    status: studentStatusEnum("status").notNull().default("active"),
    statusReason: text("status_reason"),
    groupId: integer("group_id").references(() => groupsTable.id),
    enrolledAt: date("enrolled_at", { mode: "string" }).notNull(),
    notes: text("notes"),
    createdBy: integer("created_by").references(() => usersTable.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("students_student_code_unique").on(table.studentCode)],
);

export const insertStudentSchema = createInsertSchema(studentsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type StudentRecord = typeof studentsTable.$inferSelect;
