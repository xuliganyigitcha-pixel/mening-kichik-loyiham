import { useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import {
  Activity, ArrowUpRight, BookOpen, CalendarDays, Check, CheckCheck, GraduationCap,
  LayoutDashboard, LogOut, Pencil, Plus, Search, Users, UserRound, X,
} from 'lucide-react';
import {
  getGetCurrentUserQueryKey, getGetDashboardQueryKey, getGetLessonAttendanceQueryKey,
  getGetSetupStatusQueryKey, getListGroupsQueryKey, getListLessonsQueryKey,
  getListStudentsQueryKey, getListUsersQueryKey, useBootstrapAdmin, useCreateGroup,
  useCreateLesson, useCreateStudent, useCreateUser, useGetCurrentUser, useGetDashboard,
  useGetLessonAttendance, useGetSetupStatus, useListGroups, useListLessons,
  useListStudents, useListUsers, useLogin, useLogout, useSaveLessonAttendance,
  useUpdateGroup, useUpdateStudent, useUpdateUser,
} from '@workspace/api-client-react';
import type {
  AttendanceStatus, GroupInput, LessonInput, SessionUser, StaffUser, Student,
  StudentStatus, StudyGroup,
} from '@workspace/api-client-react';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } } });
const roleName = (role: string) => ({ super_admin: 'Bosh administrator', admin: 'Administrator', teacher: 'O‘qituvchi' }[role] || role);
const statusNames: Record<string, string> = { active: 'Faol', finished: 'Tugatgan', left: 'Ketgan', frozen: 'Muzlatilgan' };
const initials = (name: string) => name.split(' ').filter(Boolean).slice(0, 2).map(x => x[0]).join('').toUpperCase();
const dateLabel = (date: string) => date ? new Date(date).toLocaleDateString('uz-UZ', { day: 'numeric', month: 'short', year: 'numeric' }) : '—';
const dayName = (date: string) => date ? new Date(date).toLocaleDateString('uz-UZ', { weekday: 'short' }) : '';

function SpinnerLines() { return <div className="loading-lines" aria-label="Yuklanmoqda">{[0, 1, 2, 3].map(i => <div className="skeleton" key={i} />)}</div>; }
function QueryError({ retry }: { retry: () => void }) { return <div className="alert"><span>Ma’lumotlarni yuklab bo‘lmadi. Aloqani tekshirib, qayta urinib ko‘ring.</span><button className="btn secondary" onClick={retry}>Qayta yuklash</button></div>; }
function Empty({ title, text }: { title: string; text: string }) { return <div className="empty"><div className="empty-mark"><BookOpen size={19} /></div><strong>{title}</strong><p>{text}</p></div>; }
function Avatar({ name }: { name: string }) { return <div className="avatar">{initials(name) || 'OM'}</div>; }
function Modal({ title, subtitle, close, children }: { title: string; subtitle?: string; close: () => void; children: ReactNode }) {
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) close(); }}><section className="modal" role="dialog" aria-modal="true">
    <div className="modal-head"><div><h2 className="modal-title">{title}</h2>{subtitle && <p className="subtitle">{subtitle}</p>}</div><button className="modal-close" onClick={close} aria-label="Yopish"><X size={16} /></button></div>{children}
  </section></div>;
}
function Field({ label, children, full }: { label: string; children: ReactNode; full?: boolean }) { return <div className={`field${full ? ' full' : ''}`}><label>{label}</label>{children}</div>; }
function Shell({ user, children }: { user: SessionUser; children: ReactNode }) {
  const [path] = useLocation();
  const logout = useLogout();
  const qc = useQueryClient();
  const nav = [
    { href: '/', label: 'Umumiy ko‘rinish', icon: LayoutDashboard, allow: ['super_admin', 'admin', 'teacher'] },
    { href: '/students', label: 'O‘quvchilar', icon: GraduationCap, allow: ['super_admin', 'admin', 'teacher'] },
    { href: '/groups', label: 'Guruhlar', icon: BookOpen, allow: ['super_admin', 'admin', 'teacher'] },
    { href: '/attendance', label: 'Davomat', icon: CheckCheck, allow: ['super_admin', 'admin', 'teacher'] },
    { href: '/staff', label: 'Jamoa', icon: Users, allow: ['super_admin', 'admin'] },
  ].filter(item => item.allow.includes(user.role));
  return <div className="app-shell">
    <aside className="sidebar">
      <Link href="/" className="brand"><span className="brand-mark">O‘</span><span><span className="brand-name">O‘quv Markaz</span><span className="brand-sub">Ta’lim boshqaruvi</span></span></Link>
      <nav><div className="nav-label">Ish maydoni</div>{nav.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`nav-link${path === href ? ' active' : ''}`} data-testid={`link-${href.replace('/', '') || 'dashboard'}`}><Icon /><span>{label}</span></Link>)}</nav>
      <div className="sidebar-bottom"><div className="sidebar-date"><strong>{new Date().toLocaleDateString('uz-UZ', { weekday: 'long', day: 'numeric', month: 'long' })}</strong>Bugungi ishlar shu yerda jamlangan.</div>
        <div className="profile-mini"><Avatar name={user.fullName} /><div className="profile-text"><div className="profile-name">{user.fullName}</div><div className="profile-role">{roleName(user.role)}</div></div><button className="logout" title="Chiqish" onClick={() => logout.mutate(undefined, { onSuccess: () => { qc.setQueryData(getGetCurrentUserQueryKey(), null); window.location.assign('/login'); } })}><LogOut size={15} /></button></div>
      </div>
    </aside>
    <main className="main-area"><header className="topbar"><div className="crumb">Ish maydoni <span> / </span> <strong>{nav.find(item => item.href === path)?.label || 'O‘quv Markaz'}</strong></div><div className="top-right"><span><i className="top-dot" /> Tizim faol</span><span className="mono">{new Date().toLocaleDateString('uz-UZ', { day: '2-digit', month: '2-digit', year: 'numeric' })}</span></div></header>{children}</main>
  </div>;
}

function AuthPage({ setup }: { setup: boolean }) {
  const [, navigate] = useLocation();
  const qc = useQueryClient();
  const setupStatus = useGetSetupStatus();
  const login = useLogin();
  const bootstrap = useBootstrapAdmin();
  const [error, setError] = useState('');
  const busy = login.isPending || bootstrap.isPending;
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); setError('');
    const data = new FormData(e.currentTarget);
    if (setup) {
      bootstrap.mutate({ data: { fullName: String(data.get('fullName')), login: String(data.get('login')), password: String(data.get('password')) } }, {
        onSuccess: () => { qc.invalidateQueries({ queryKey: getGetSetupStatusQueryKey() }); qc.invalidateQueries({ queryKey: getGetCurrentUserQueryKey() }); navigate('/'); },
        onError: () => setError('Hisob yaratilmadi. Kiritilgan ma’lumotlarni tekshirib ko‘ring.'),
      });
    } else {
      login.mutate({ data: { login: String(data.get('login')), password: String(data.get('password')) } }, {
        onSuccess: () => { qc.invalidateQueries({ queryKey: getGetCurrentUserQueryKey() }); navigate('/'); },
        onError: () => setError('Login yoki parol noto‘g‘ri. Yana bir bor tekshiring.'),
      });
    }
  };
  if (setupStatus.isLoading) return <div className="auth-screen"><SpinnerLines /></div>;
  return <div className="auth-screen">
    <section className="auth-art"><Link href="/" className="brand"><span className="brand-mark">O‘</span><span><span className="brand-name">O‘quv Markaz</span><span className="brand-sub">Ta’lim boshqaruvi</span></span></Link>
      <div className="auth-copy"><div className="eyebrow">Markazingizning ish maydoni</div><h1>Ta’limning har kuni — tartib bilan.</h1><p>O‘quvchilar, darslar va davomat. Markazingiz ishini bir joyda, ishonch bilan boshqaring.</p></div><div className="auth-foot">O‘QUV MARKAZ · XODIMLAR UCHUN</div>
    </section>
    <section className="auth-form-side"><form className="auth-form" onSubmit={submit}>
      <div className="mobile-brand"><span className="brand-mark">O‘</span><b>O‘quv Markaz</b></div>
      <div className="eyebrow">{setup ? 'Boshlang‘ich sozlash' : 'Xodimlar uchun'}</div>
      <h2>{setup ? 'Birinchi administrator' : 'Xush kelibsiz'}</h2>
      <p>{setup ? 'Markazingiz uchun super-admin hisobini yarating.' : 'Ish maydoniga kirish uchun hisob ma’lumotlaringizni kiriting.'}</p>
      {setup && <Field label="To‘liq ism"><input name="fullName" required minLength={2} maxLength={120} placeholder="Masalan, Dilnoza Karimova" data-testid="input-full-name" /></Field>}
      <Field label="Login"><input name="login" required minLength={setup ? 3 : 1} maxLength={60} autoComplete="username" placeholder="Hisob logini" data-testid="input-login" /></Field>
      <Field label="Parol"><input name="password" type="password" required minLength={setup ? 8 : 1} autoComplete={setup ? 'new-password' : 'current-password'} placeholder="••••••••" data-testid="input-password" /></Field>
      {error && <p className="form-error" role="alert">{error}</p>}
      {setupStatus.isError && !setup && <div className="form-error">Sozlash holatini tekshirib bo‘lmadi. Sahifani yangilang.</div>}
      <button className="btn" disabled={busy} data-testid="button-submit">{busy ? 'Tekshirilmoqda…' : setup ? 'Administrator yaratish' : 'Ish maydoniga kirish'} <ArrowUpRight size={15} /></button>
    </form></section>
  </div>;
}

function Dashboard({ user }: { user: SessionUser }) {
  const dash = useGetDashboard();
  const groupQuery = useListGroups();
  const summary = dash.data;
  return <div className="page">
    <div className="page-heading"><div><div className="eyebrow">Bugungi holat · {roleName(user.role)}</div><h1>Assalomu alaykum, {user.fullName.split(' ')[0]}.</h1><p className="subtitle">Markazingiz ishlarining qisqa va aniq manzarasi.</p></div><Link href="/attendance" className="btn"><CheckCheck /> Davomatni belgilash</Link></div>
    {dash.isLoading ? <div className="surface"><SpinnerLines /></div> : dash.isError ? <QueryError retry={() => dash.refetch()} /> : summary && <>
      <div className="stat-grid">
        <Stat icon={<GraduationCap />} label="Faol o‘quvchilar" value={summary.activeStudents} note="Markazdagi o‘quvchilar" />
        <Stat icon={<BookOpen />} label="Faol guruhlar" value={summary.activeGroups} note="Hozir dars o‘tayotgan guruhlar" />
        <Stat icon={<UserRound />} label={user.role === 'teacher' ? 'Guruhlarim' : 'O‘qituvchilar'} value={user.role === 'teacher' ? (groupQuery.data || []).filter(group => group.teacherId === user.id && group.isActive).length : summary.teachers} note={user.role === 'teacher' ? 'Biriktirilgan guruhlar' : 'Faol pedagoglar'} />
        <Stat icon={<CalendarDays />} label="Bugungi darslar" value={summary.todayLessons} note={`Davomat ${summary.todayAttendancePercent}%`} />
      </div>
      <div className="dashboard-grid">
        <section className="surface panel"><div className="panel-head"><h2 className="panel-title">Bugungi darslar</h2><Link className="panel-link" href="/attendance">Davomatga o‘tish <ArrowUpRight size={12} /></Link></div>
          {summary.todayLessonsList.length ? summary.todayLessonsList.map(lesson => <div className="lesson-row" key={lesson.id}><div className="lesson-time">{new Date(lesson.date).toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' })}</div><div><div className="lesson-name">{lesson.groupName}</div><div className="lesson-meta">{lesson.topic || 'Mavzu belgilanmagan'} · {lesson.studentCount} o‘quvchi</div></div><span className={`lesson-state${lesson.attendanceMarked ? '' : ' warn'}`}>{lesson.attendanceMarked ? 'Belgilandi' : 'Kutilmoqda'}</span></div>) : <Empty title="Bugun dars yo‘q" text="Yangi darslar jadvalga qo‘shilganda shu yerda ko‘rinadi." />}
        </section>
        <section className="surface panel"><div className="panel-head"><h2 className="panel-title">Davomat sur’ati</h2><span className="status active">{summary.todayAttendancePercent}% bugun</span></div>
          {summary.attendanceTrend.length ? <div className="trend"><span className="trend-caption">Oxirgi darslar</span>{summary.attendanceTrend.map((point, i) => <div className="trend-column" key={`${point.date}-${i}`}><div className="trend-bar" title={`${point.percent}%`} style={{ height: `${Math.max(7, point.percent)}%` }} /><span className="trend-day">{dayName(point.date)}</span></div>)}</div> : <Empty title="Hozircha ma’lumot yo‘q" text="Davomat qaydlari yig‘ilgach, bu yerda ko‘rinadi." />}
        </section>
      </div>
      <section className="surface panel" style={{ marginTop: 18 }}><div className="panel-head"><h2 className="panel-title">Yaqinda qo‘shilgan o‘quvchilar</h2><Link href="/students" className="panel-link">Barchasini ko‘rish <ArrowUpRight size={12} /></Link></div>
        {summary.recentStudents.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>O‘quvchi</th><th>Guruh</th><th>Qabul qilingan</th><th>Davomat</th><th>Holat</th></tr></thead><tbody>{summary.recentStudents.map(student => <StudentRow key={student.id} student={student} />)}</tbody></table></div> : <Empty title="Yangi o‘quvchilar yo‘q" text="Ro‘yxatdan o‘quvchi qo‘shilsa, bu yerda ko‘rasiz." />}
      </section>
    </>}
  </div>;
}
function Stat({ icon, label, value, note }: { icon: ReactNode; label: string; value: number; note: string }) { return <div className="surface stat-card"><div className="stat-label"><span className="stat-icon">{icon}</span>{label}</div><div className="stat-value">{value.toLocaleString('uz-UZ')}</div><div className="stat-note">{note}</div></div>; }
function StudentRow({ student, action }: { student: Student; action?: ReactNode }) {
  return <tr data-testid={`row-student-${student.id}`}><td><div className="person"><Avatar name={`${student.firstName} ${student.lastName}`} /><div><div className="person-name">{student.firstName} {student.lastName}</div><div className="person-code">{student.studentCode}</div></div></div></td><td>{student.groupName || 'Guruhsiz'}</td><td>{dateLabel(student.enrolledAt)}</td><td>{student.attendancePercent}%</td><td><span className={`status ${student.status}`}>{statusNames[student.status]}</span></td>{action && <td><div className="row-actions">{action}</div></td>}</tr>;
}
function StudentsPage() {
  const [search, setSearch] = useState(''); const [status, setStatus] = useState(''); const [groupId, setGroupId] = useState(''); const [modal, setModal] = useState<Student | null | false>(false);
  const params = { search: search || undefined, status: status ? status as StudentStatus : undefined, groupId: groupId ? Number(groupId) : undefined, page: 1, pageSize: 100 };
  const students = useListStudents(params); const groups = useListGroups(); const create = useCreateStudent(); const update = useUpdateStudent(); const qc = useQueryClient();
  const refresh = () => { qc.invalidateQueries({ queryKey: getListStudentsQueryKey() }); qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); };
  const save = (e: FormEvent<HTMLFormElement>) => { e.preventDefault(); const f = new FormData(e.currentTarget); const payload = { firstName: String(f.get('firstName')), lastName: String(f.get('lastName')), phone: String(f.get('phone')), address: String(f.get('address')) || null, groupId: String(f.get('groupId')) ? Number(f.get('groupId')) : null, enrolledAt: String(f.get('enrolledAt')), notes: String(f.get('notes')) || null };
    if (modal) update.mutate({ studentId: modal.id, data: { ...payload, status: String(f.get('status')) as StudentStatus, statusReason: String(f.get('statusReason')) } }, { onSuccess: () => { refresh(); setModal(false); } });
    else create.mutate({ data: payload }, { onSuccess: () => { refresh(); setModal(false); } });
  };
  const changeStatus = (student: Student) => { const next: StudentStatus = student.status === 'active' ? 'frozen' : 'active'; if (window.confirm(`${student.firstName} ${student.lastName} holatini “${statusNames[next]}”ga o‘zgartirasizmi?`)) update.mutate({ studentId: student.id, data: { status: next } }, { onSuccess: refresh }); };
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">O‘quvchilar bazasi</div><h1>O‘quvchilar</h1><p className="subtitle">O‘quvchi ma’lumotlari va holatini boshqaring.</p></div><button className="btn" onClick={() => setModal(null)}><Plus /> O‘quvchi qo‘shish</button></div>
    <div className="surface panel"><div className="toolbar"><div className="searchbox"><Search /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Ism, telefon yoki ID bo‘yicha izlash" data-testid="input-student-search" /></div><select className="control select-control" value={groupId} onChange={e => setGroupId(e.target.value)}><option value="">Barcha guruhlar</option>{(groups.data || []).map(g => <option key={g.id} value={g.id}>{g.name}</option>)}</select><select className="control select-control" value={status} onChange={e => setStatus(e.target.value)}><option value="">Barcha holatlar</option>{Object.entries(statusNames).map(([key, value]) => <option key={key} value={key}>{value}</option>)}</select></div>
      {students.isLoading ? <SpinnerLines /> : students.isError ? <QueryError retry={() => students.refetch()} /> : students.data?.items.length ? <><div className="table-wrap"><table className="data-table"><thead><tr><th>O‘quvchi</th><th>Guruh</th><th>Qabul sanasi</th><th>Davomat</th><th>Holat</th><th /></tr></thead><tbody>{students.data.items.map(student => <StudentRow key={student.id} student={student} action={<><button className="row-action" title="Tahrirlash" onClick={() => setModal(student)}><Pencil size={14} /></button><button className="row-action" title={student.status === 'active' ? 'Muzlatish' : 'Faollashtirish'} onClick={() => changeStatus(student)}><Activity size={14} /></button></>} />)}</tbody></table></div><div className="stat-note" style={{ paddingTop: 14 }}>Jami {students.data.total} nafar o‘quvchi</div></> : <Empty title="O‘quvchi topilmadi" text="Qidiruv yoki filtrni o‘zgartiring, yoxud yangi o‘quvchi qo‘shing." />}
    </div>
    {modal !== false && <Modal title={modal ? 'O‘quvchini tahrirlash' : 'Yangi o‘quvchi'} subtitle="Asosiy ma’lumotlar. Yulduzcha bilan belgilangan maydonlar majburiy." close={() => setModal(false)}><form onSubmit={save}><div className="form-grid">
      <Field label="Ism"><input name="firstName" required defaultValue={modal?.firstName} data-testid="input-first-name" /></Field><Field label="Familiya"><input name="lastName" required defaultValue={modal?.lastName} data-testid="input-last-name" /></Field>
      <Field label="Telefon"><input name="phone" required type="tel" defaultValue={modal?.phone} placeholder="+998 90 123 45 67" /></Field><Field label="Qabul sanasi"><input name="enrolledAt" required type="date" defaultValue={modal?.enrolledAt?.slice(0, 10) || new Date().toISOString().slice(0, 10)} /></Field>
      <Field label="Guruh"><select name="groupId" defaultValue={modal?.groupId || ''}><option value="">Guruhsiz</option>{(groups.data || []).map(g => <option value={g.id} key={g.id}>{g.name}</option>)}</select></Field><Field label="Manzil"><input name="address" defaultValue={modal?.address || ''} /></Field>{modal && <><Field label="O‘quvchi holati"><select name="status" defaultValue={modal.status}>{Object.entries(statusNames).map(([key, value]) => <option value={key} key={key}>{value}</option>)}</select></Field><Field label="Holat bo‘yicha izoh"><input name="statusReason" placeholder="Ixtiyoriy sabab" /></Field></>}<Field label="Izoh" full><textarea name="notes" defaultValue={modal?.notes || ''} /></Field>
    </div><div className="modal-actions"><button type="button" className="btn secondary" onClick={() => setModal(false)}>Bekor qilish</button><button className="btn" disabled={create.isPending || update.isPending}>{create.isPending || update.isPending ? 'Saqlanmoqda…' : 'Saqlash'}</button></div></form></Modal>}
  </div>;
}

function GroupsPage() {
  const groups = useListGroups(); const users = useListUsers(); const create = useCreateGroup(); const update = useUpdateGroup(); const lessonCreate = useCreateLesson();
  const qc = useQueryClient(); const [modal, setModal] = useState<StudyGroup | null | false>(false); const [schedule, setSchedule] = useState<StudyGroup | false>(false); const [error, setError] = useState('');
  const invalidate = () => { qc.invalidateQueries({ queryKey: getListGroupsQueryKey() }); qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); };
  const saveGroup = (e: FormEvent<HTMLFormElement>) => { e.preventDefault(); const f = new FormData(e.currentTarget); const data: GroupInput = { name: String(f.get('name')), teacherId: String(f.get('teacherId')) ? Number(f.get('teacherId')) : null, scheduleText: String(f.get('scheduleText')) || null, startDate: String(f.get('startDate')) };
    const done = () => { invalidate(); setModal(false); };
    if (modal) update.mutate({ groupId: modal.id, data }, { onSuccess: done }); else create.mutate({ data }, { onSuccess: done });
  };
  const saveLesson = (e: FormEvent<HTMLFormElement>) => { e.preventDefault(); const f = new FormData(e.currentTarget); setError('');
    lessonCreate.mutate({ data: { groupId: Number(f.get('groupId')), date: `${String(f.get('date'))}T${String(f.get('time'))}:00`, topic: String(f.get('topic')) || null, isCancelled: false, cancelReason: null } }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListLessonsQueryKey() }); qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); setSchedule(false); }, onError: () => setError('Dars jadvalga qo‘shilmadi. Ma’lumotlarni tekshiring.') });
  };
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">Ta’lim tuzilmasi</div><h1>Guruhlar</h1><p className="subtitle">O‘qituvchilar, dars jadvali va guruh tarkibi.</p></div><button className="btn" onClick={() => setModal(null)}><Plus /> Guruh yaratish</button></div>
    {groups.isLoading ? <div className="surface"><SpinnerLines /></div> : groups.isError ? <QueryError retry={() => groups.refetch()} /> : groups.data?.length ? <div className="surface table-wrap"><table className="data-table"><thead><tr><th>Guruh</th><th>O‘qituvchi</th><th>Dars vaqti</th><th>O‘quvchilar</th><th>Boshlangan</th><th>Holat</th><th /></tr></thead><tbody>{groups.data.map(g => <tr key={g.id} data-testid={`row-group-${g.id}`}><td><div className="person"><div className="avatar"><BookOpen size={14} /></div><div><div className="person-name">{g.name}</div><div className="person-code">Guruh #{String(g.id).padStart(3, '0')}</div></div></div></td><td>{g.teacherName || 'Biriktirilmagan'}</td><td>{g.scheduleText || 'Jadval kiritilmagan'}</td><td>{g.studentCount}</td><td>{dateLabel(g.startDate)}</td><td><span className={`status ${g.isActive ? 'active' : 'inactive'}`}>{g.isActive ? 'Faol' : 'Nofaol'}</span></td><td><div className="row-actions"><button className="row-action" title="Tahrirlash" onClick={() => setModal(g)}><Pencil size={14} /></button><button className="row-action" title="Dars rejalash" onClick={() => setSchedule(g)}><CalendarDays size={14} /></button><button className="row-action" title={g.isActive ? 'Nofaol qilish' : 'Faollashtirish'} onClick={() => update.mutate({ groupId: g.id, data: { isActive: !g.isActive } }, { onSuccess: invalidate })}><Activity size={14} /></button></div></td></tr>)}</tbody></table></div> : <div className="surface"><Empty title="Hozircha guruhlar yo‘q" text="Yangi guruh yarating va o‘qituvchini biriktiring." /></div>}
    {modal !== false && <Modal title={modal ? 'Guruhni tahrirlash' : 'Yangi guruh'} close={() => setModal(false)}><form onSubmit={saveGroup}><div className="form-grid"><Field label="Guruh nomi"><input name="name" required defaultValue={modal?.name} placeholder="Masalan, Ingliz tili · B1" /></Field><Field label="O‘qituvchi"><select name="teacherId" defaultValue={modal?.teacherId || ''}><option value="">Biriktirilmagan</option>{(users.data || []).filter(u => u.role === 'teacher' && u.isActive).map(u => <option value={u.id} key={u.id}>{u.fullName}</option>)}</select></Field><Field label="Dars jadvali"><input name="scheduleText" defaultValue={modal?.scheduleText || ''} placeholder="Dush / Chor / Jum · 14:00" /></Field><Field label="Boshlanish sanasi"><input name="startDate" type="date" required defaultValue={modal?.startDate?.slice(0, 10) || new Date().toISOString().slice(0, 10)} /></Field></div><div className="modal-actions"><button type="button" className="btn secondary" onClick={() => setModal(false)}>Bekor qilish</button><button className="btn" disabled={create.isPending || update.isPending}>Guruhni saqlash</button></div></form></Modal>}
    {schedule && <Modal title="Darsni jadvalga qo‘shish" subtitle={schedule.name} close={() => setSchedule(false)}><form onSubmit={saveLesson}><div className="form-grid"><Field label="Sana"><input name="date" type="date" required defaultValue={new Date().toISOString().slice(0, 10)} /></Field><Field label="Boshlanish vaqti"><input name="time" type="time" required defaultValue="14:00" /></Field><Field label="Dars mavzusi" full><input name="topic" placeholder="Masalan, Unit 4 — Speaking" /></Field></div>{error && <p className="form-error">{error}</p>}<div className="modal-actions"><button type="button" className="btn secondary" onClick={() => setSchedule(false)}>Bekor qilish</button><button className="btn" disabled={lessonCreate.isPending}>Darsni saqlash</button></div></form></Modal>}
  </div>;
}

function AttendancePage() {
  const [lessonId, setLessonId] = useState(0); const [selected, setSelected] = useState<Record<number, AttendanceStatus>>({});
  const lessons = useListLessons(); const attendance = useGetLessonAttendance(lessonId, { query: { enabled: !!lessonId, queryKey: getGetLessonAttendanceQueryKey(lessonId) } });
  const save = useSaveLessonAttendance(); const qc = useQueryClient();
  const onLoad = (id: number) => { setLessonId(id); setSelected({}); };
  const records = attendance.data?.records || [];
  const saveRecords = () => {
    if (!lessonId || !records.length) return;
    const entries = records.map(record => ({ studentId: record.studentId, status: selected[record.studentId] || record.status || 'present' as AttendanceStatus }));
    save.mutate({ lessonId, data: { records: entries } }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getGetLessonAttendanceQueryKey(lessonId) }); qc.invalidateQueries({ queryKey: getListLessonsQueryKey() }); qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); } });
  };
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">Dars qaydlari</div><h1>Davomat</h1><p className="subtitle">Darsni tanlang va har bir o‘quvchining holatini belgilang.</p></div></div>
    <div className="surface panel" style={{ marginBottom: 16 }}><div className="toolbar" style={{ margin: 0 }}><label style={{ fontSize: 11, fontWeight: 700, color: '#526358' }}>Darsni tanlang</label><select className="control select-control" style={{ flex: 1 }} value={lessonId || ''} onChange={e => onLoad(Number(e.target.value))}><option value="">Dars tanlanmagan</option>{(lessons.data || []).filter(l => !l.isCancelled).map(l => <option value={l.id} key={l.id}>{dateLabel(l.date)} · {new Date(l.date).toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' })} · {l.groupName}</option>)}</select><span className="stat-note">{lessons.data?.length || 0} ta dars</span></div>{lessons.isError && <QueryError retry={() => lessons.refetch()} />}</div>
    {lessonId ? <section className="surface panel"><div className="panel-head"><div><h2 className="panel-title">{attendance.data?.lesson.groupName || 'Tanlangan dars'}</h2><div className="stat-note" style={{ marginTop: 5 }}>{attendance.data?.lesson.topic || 'Dars mavzusi kiritilmagan'} · {attendance.data ? dateLabel(attendance.data.lesson.date) : ''}</div></div>{attendance.data && <span className="status active">{records.length} o‘quvchi</span>}</div>
      {attendance.isLoading ? <SpinnerLines /> : attendance.isError ? <QueryError retry={() => attendance.refetch()} /> : records.length ? <><div className="table-wrap"><table className="data-table"><thead><tr><th>O‘quvchi</th><th>Holat</th><th>Belgilangan</th></tr></thead><tbody>{records.map(record => <tr key={record.studentId}><td><div className="person"><Avatar name={record.studentName} /><div><div className="person-name">{record.studentName}</div><div className="person-code">{record.studentCode}</div></div></div></td><td><div className="attendance-options">{(['present', 'absent_unexcused', 'absent_excused', 'late'] as AttendanceStatus[]).map((s, i) => <button key={s} className={`${(selected[record.studentId] || record.status || 'present') === s ? `chosen ${s === 'absent_unexcused' || s === 'absent_excused' ? 'absent' : s === 'late' ? 'late' : ''}` : ''}`} onClick={() => setSelected(prev => ({ ...prev, [record.studentId]: s }))}>{['Keldi', 'Sababsiz', 'Sababli', 'Kechikdi'][i]}</button>)}</div></td><td>{record.markedAt ? new Date(record.markedAt).toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' }) : '—'}</td></tr>)}</tbody></table></div><div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 18 }}><button className="btn" onClick={saveRecords} disabled={save.isPending}><Check size={15} />{save.isPending ? 'Saqlanmoqda…' : 'Davomatni saqlash'}</button></div>{save.isError && <p className="form-error">Davomat saqlanmadi. Qayta urinib ko‘ring.</p>}</> : <Empty title="Ro‘yxatda o‘quvchi yo‘q" text="Tanlangan dars guruhida faol o‘quvchi topilmadi." />}
    </section> : <div className="surface"><Empty title="Dars tanlanmagan" text="Davomatni ko‘rish va belgilash uchun yuqoridan darsni tanlang." /></div>}
  </div>;
}

function StaffPage({ currentUser }: { currentUser: SessionUser }) {
  const users = useListUsers(); const create = useCreateUser(); const update = useUpdateUser(); const qc = useQueryClient();
  const [modal, setModal] = useState<StaffUser | null | false>(false); const [error, setError] = useState('');
  const refresh = () => { qc.invalidateQueries({ queryKey: getListUsersQueryKey() }); qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); };
  const save = (e: FormEvent<HTMLFormElement>) => { e.preventDefault(); setError(''); const f = new FormData(e.currentTarget);
    if (modal) update.mutate({ userId: modal.id, data: { fullName: String(f.get('fullName')), phone: String(f.get('phone')) || null } }, { onSuccess: () => { refresh(); setModal(false); } });
    else create.mutate({ data: { fullName: String(f.get('fullName')), login: String(f.get('login')), password: String(f.get('password')), phone: String(f.get('phone')) || null, role: String(f.get('role')) as 'admin' | 'teacher' } }, { onSuccess: () => { refresh(); setModal(false); }, onError: () => setError('Hisob yaratilmadi. Login band yoki ma’lumotlar noto‘g‘ri bo‘lishi mumkin.') });
  };
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">Hisoblar va ruxsatlar</div><h1>Jamoa</h1><p className="subtitle">Xodimlar hisoblari va kirish huquqlarini boshqaring.</p></div><button className="btn" onClick={() => setModal(null)}><Plus /> Xodim qo‘shish</button></div>
    {users.isLoading ? <div className="surface"><SpinnerLines /></div> : users.isError ? <QueryError retry={() => users.refetch()} /> : users.data?.length ? <div className="surface table-wrap"><table className="data-table"><thead><tr><th>Xodim</th><th>Rol</th><th>Login</th><th>Guruhlar</th><th>Qo‘shilgan</th><th>Holat</th><th /></tr></thead><tbody>{users.data.map(person => <tr key={person.id} data-testid={`row-staff-${person.id}`}><td><div className="person"><Avatar name={person.fullName} /><div><div className="person-name">{person.fullName}</div><div className="person-code">{person.phone || 'Telefon kiritilmagan'}</div></div></div></td><td>{roleName(person.role)}</td><td className="mono">{person.login}</td><td>{person.groupCount}</td><td>{dateLabel(person.createdAt)}</td><td><span className={`status ${person.isActive ? 'active' : 'inactive'}`}>{person.isActive ? 'Faol' : 'Nofaol'}</span></td><td><div className="row-actions"><button className="row-action" title="Tahrirlash" onClick={() => setModal(person)}><Pencil size={14} /></button>{person.id !== currentUser.id && <button className="row-action" title={person.isActive ? 'Nofaol qilish' : 'Faollashtirish'} onClick={() => update.mutate({ userId: person.id, data: { isActive: !person.isActive } }, { onSuccess: refresh })}><Activity size={14} /></button>}</div></td></tr>)}</tbody></table></div> : <div className="surface"><Empty title="Jamoa ro‘yxati bo‘sh" text="Markaz xodimlari uchun hisob yarating." /></div>}
    {modal !== false && <Modal title={modal ? 'Xodim ma’lumotlarini tahrirlash' : 'Yangi xodim hisobi'} close={() => setModal(false)}><form onSubmit={save}><div className="form-grid"><Field label="To‘liq ism"><input name="fullName" required defaultValue={modal?.fullName} /></Field>{!modal && <Field label="Rol"><select name="role" defaultValue="teacher"><option value="teacher">O‘qituvchi</option><option value="admin">Administrator</option></select></Field>}{!modal && <Field label="Login"><input name="login" required minLength={3} maxLength={60} /></Field>}{!modal && <Field label="Vaqtinchalik parol"><input name="password" required type="password" minLength={8} /></Field>}<Field label="Telefon"><input name="phone" type="tel" defaultValue={modal?.phone || ''} /></Field></div>{error && <p className="form-error">{error}</p>}<div className="modal-actions"><button type="button" className="btn secondary" onClick={() => setModal(false)}>Bekor qilish</button><button className="btn" disabled={create.isPending || update.isPending}>{create.isPending || update.isPending ? 'Saqlanmoqda…' : 'Saqlash'}</button></div></form></Modal>}
  </div>;
}

function AppRoutes() {
  const [path] = useLocation();
  const setup = useGetSetupStatus();
  const current = useGetCurrentUser({ query: { queryKey: getGetCurrentUserQueryKey(), retry: false } });
  if (setup.isLoading || current.isLoading) return <div className="auth-screen"><SpinnerLines /></div>;
  const needsSetup = setup.data?.needsBootstrap === true;
  if (needsSetup) return path === '/setup' ? <AuthPage setup /> : <AuthPage setup />;
  if (path === '/setup') return <AuthPage setup={false} />;
  if (!current.data || current.isError) return path === '/login' ? <AuthPage setup={false} /> : <AuthPage setup={false} />;
  const user = current.data;
  return <Shell user={user}><Switch>
    <Route path="/" component={() => <Dashboard user={user} />} />
    <Route path="/students" component={StudentsPage} />
    <Route path="/groups" component={GroupsPage} />
    <Route path="/attendance" component={AttendancePage} />
    <Route path="/staff" component={() => user.role === 'teacher' ? <NotFound /> : <StaffPage currentUser={user} />} />
    <Route component={NotFound} />
  </Switch></Shell>;
}
function App() {
  return <QueryClientProvider client={queryClient}><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><AppRoutes /></WouterRouter></QueryClientProvider>;
}
export default App;
