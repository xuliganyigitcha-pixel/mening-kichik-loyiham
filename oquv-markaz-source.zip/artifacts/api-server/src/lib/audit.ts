import type { Request } from "express";
import { db, auditLogsTable } from "@workspace/db";
import type { AuthenticatedUser } from "./auth";
import { requestIp } from "./auth";

export async function writeAudit(
  req: Request,
  user: AuthenticatedUser | null,
  action: string,
  entityType: string,
  entityId: string | number,
  oldValue: unknown = null,
  newValue: unknown = null,
): Promise<void> {
  await db.insert(auditLogsTable).values({
    userId: user?.id ?? null,
    action,
    entityType,
    entityId: String(entityId),
    oldValue: oldValue as Record<string, unknown> | null,
    newValue: newValue as Record<string, unknown> | null,
    ip: requestIp(req),
  });
}
