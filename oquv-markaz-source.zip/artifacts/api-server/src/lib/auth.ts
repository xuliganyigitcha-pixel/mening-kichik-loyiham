import { createHash, randomBytes } from "node:crypto";
import type { Request, Response } from "express";
import { eq } from "drizzle-orm";
import { db, sessionsTable, usersTable } from "@workspace/db";

export const SESSION_COOKIE = "om_session";
export const SESSION_DURATION_MS = 7 * 24 * 60 * 60 * 1000;

export type AuthenticatedUser = typeof usersTable.$inferSelect;

export function getCookieValue(req: Request, name: string): string | null {
  const cookieHeader = req.headers.cookie;
  if (!cookieHeader) return null;
  for (const part of cookieHeader.split(";")) {
    const separator = part.indexOf("=");
    if (separator < 0) continue;
    if (part.slice(0, separator).trim() === name) {
      return decodeURIComponent(part.slice(separator + 1).trim());
    }
  }
  return null;
}

export function hashSessionToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

export function newSessionToken(): string {
  return randomBytes(32).toString("base64url");
}

export function setSessionCookie(res: Response, token: string): void {
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_DURATION_MS,
  });
}

export function clearSessionCookie(res: Response): void {
  res.clearCookie(SESSION_COOKIE, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
  });
}

export async function getAuthenticatedUser(req: Request): Promise<AuthenticatedUser | null> {
  const token = getCookieValue(req, SESSION_COOKIE);
  if (!token) return null;
  const [session] = await db
    .select({ user: usersTable, expiresAt: sessionsTable.expiresAt })
    .from(sessionsTable)
    .innerJoin(usersTable, eq(sessionsTable.userId, usersTable.id))
    .where(eq(sessionsTable.refreshTokenHash, hashSessionToken(token)))
    .limit(1);
  if (!session || session.expiresAt.getTime() <= Date.now() || !session.user.isActive) {
    return null;
  }
  return session.user;
}

export function requestIp(req: Request): string {
  return req.ip || req.socket.remoteAddress || "unknown";
}

export function sessionUser(user: AuthenticatedUser) {
  return {
    id: user.id,
    role: user.role,
    login: user.login,
    fullName: user.fullName,
    isActive: user.isActive,
  };
}
