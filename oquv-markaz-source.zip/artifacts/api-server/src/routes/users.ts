import { Router, type IRouter } from "express";
import bcrypt from "bcryptjs";
import { and, count, eq, sql } from "drizzle-orm";
import { db, groupsTable, sessionsTable, usersTable } from "@workspace/db";
import {
  CreateUserBody,
  CreateUserResponse,
  ListUsersResponse,
  UpdateUserBody,
  UpdateUserParams,
  UpdateUserResponse,
} from "@workspace/api-zod";
import { getAuthenticatedUser } from "../lib/auth";
import { writeAudit } from "../lib/audit";

const router: IRouter = Router();
const PASSWORD_POLICY = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,128}$/;

function isAdmin(role: string): boolean {
  return role === "super_admin" || role === "admin";
}

function userDto(
  user: typeof usersTable.$inferSelect,
  groupCount: number,
) {
  return {
    id: user.id,
    role: user.role,
    login: user.login,
    fullName: user.fullName,
    phone: user.phone,
    isActive: user.isActive,
    groupCount,
    createdAt: user.createdAt.toISOString(),
  };
}

router.get("/users", async (req, res): Promise<void> => {
  const current = await getAuthenticatedUser(req);
  if (!current) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  if (!isAdmin(current.role)) {
    res.status(403).json({ error: "Xodimlar ro‘yxati faqat admin uchun." });
    return;
  }
  const users = await db
    .select()
    .from(usersTable)
    .orderBy(sql`${usersTable.isActive} DESC`, usersTable.role, usersTable.fullName);
  const rows = await Promise.all(
    users.map(async (user) => {
      const [result] = await db
        .select({ total: count() })
        .from(groupsTable)
        .where(eq(groupsTable.teacherId, user.id));
      return userDto(user, result.total);
    }),
  );
  res.json(ListUsersResponse.parse(rows));
});

router.post("/users", async (req, res): Promise<void> => {
  const current = await getAuthenticatedUser(req);
  if (!current) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  if (!isAdmin(current.role)) {
    res.status(403).json({ error: "Xodim hisobini faqat admin yaratadi." });
    return;
  }
  const parsed = CreateUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (current.role === "admin" && parsed.data.role !== "teacher") {
    res.status(403).json({ error: "Admin faqat o‘qituvchi hisobi yarata oladi." });
    return;
  }
  if (!PASSWORD_POLICY.test(parsed.data.password)) {
    res.status(400).json({ error: "Parolda katta-kichik harf va raqam bo‘lishi kerak." });
    return;
  }
  const login = parsed.data.login.trim().toLowerCase();
  const [created] = await db
    .insert(usersTable)
    .values({
      role: parsed.data.role,
      login,
      passwordHash: await bcrypt.hash(parsed.data.password, 12),
      fullName: parsed.data.fullName.trim(),
      phone: parsed.data.phone,
      createdBy: current.id,
    })
    .onConflictDoNothing({ target: usersTable.login })
    .returning();
  if (!created) {
    res.status(409).json({ error: "Bu login allaqachon ishlatilgan." });
    return;
  }
  await writeAudit(req, current, "create", "user", created.id, null, {
    role: created.role,
    login: created.login,
    fullName: created.fullName,
    phone: created.phone,
  });
  res.status(201).json(CreateUserResponse.parse(userDto(created, 0)));
});

router.patch("/users/:userId", async (req, res): Promise<void> => {
  const current = await getAuthenticatedUser(req);
  if (!current) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  if (!isAdmin(current.role)) {
    res.status(403).json({ error: "Xodim hisobini faqat admin boshqaradi." });
    return;
  }
  const params = UpdateUserParams.safeParse(req.params);
  const parsed = UpdateUserBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: params.error?.message ?? parsed.error?.message ?? "Noto‘g‘ri so‘rov." });
    return;
  }
  const [target] = await db.select().from(usersTable).where(eq(usersTable.id, params.data.userId)).limit(1);
  if (!target) {
    res.status(404).json({ error: "Xodim topilmadi." });
    return;
  }
  if (current.role === "admin" && target.role !== "teacher") {
    res.status(403).json({ error: "Admin faqat o‘qituvchilar hisobini boshqaradi." });
    return;
  }
  if (target.id === current.id && parsed.data.isActive === false) {
    res.status(400).json({ error: "O‘z hisobingizni bloklay olmaysiz." });
    return;
  }
  const [updated] = await db
    .update(usersTable)
    .set(parsed.data)
    .where(eq(usersTable.id, target.id))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Xodim topilmadi." });
    return;
  }
  if (!updated.isActive) {
    await db.delete(sessionsTable).where(eq(sessionsTable.userId, updated.id));
  }
  const [groupResult] = await db
    .select({ total: count() })
    .from(groupsTable)
    .where(eq(groupsTable.teacherId, updated.id));
  await writeAudit(req, current, "update", "user", updated.id, {
    role: target.role,
    fullName: target.fullName,
    phone: target.phone,
    isActive: target.isActive,
  }, {
    role: updated.role,
    fullName: updated.fullName,
    phone: updated.phone,
    isActive: updated.isActive,
  });
  res.json(UpdateUserResponse.parse(userDto(updated, groupResult.total)));
});

export default router;
