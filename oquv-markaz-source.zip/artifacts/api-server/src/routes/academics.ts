import { Router, type IRouter } from "express";
import { and, count, eq, gte, inArray, lte, sql } from "drizzle-orm";
import {
  attendanceTable,
  db,
  groupsTable,
  lessonsTable,
  studentsTable,
  usersTable,
} from "@workspace/db";
import {
  CreateGroupBody,
  CreateGroupResponse,
  CreateLessonBody,
  CreateLessonResponse,
  GetLessonAttendanceParams,
  GetLessonAttendanceResponse,
  ListGroupsResponse,
  ListLessonsQueryParams,
  ListLessonsResponse,
  SaveLessonAttendanceBody,
  SaveLessonAttendanceParams,
  SaveLessonAttendanceResponse,
  UpdateGroupBody,
  UpdateGroupParams,
  UpdateGroupResponse,
} from "@workspace/api-zod";
import { getAuthenticatedUser, type AuthenticatedUser } from "../lib/auth";
import { writeAudit } from "../lib/audit";

const router: IRouter = Router();

async function groupAccess(user: AuthenticatedUser, groupId: number): Promise<boolean> {
  if (user.role !== "teacher") return true;
  const [group] = await db
    .select({ id: groupsTable.id })
    .from(groupsTable)
    .where(and(eq(groupsTable.id, groupId), eq(groupsTable.teacherId, user.id)))
    .limit(1);
  return Boolean(group);
}

function canManage(user: AuthenticatedUser): boolean {
  return user.role === "super_admin" || user.role === "admin";
}

async function lessonDto(
  lesson: typeof lessonsTable.$inferSelect,
  groupName: string,
) {
  const [studentCount] = await db
    .select({ total: count() })
    .from(studentsTable)
    .where(and(eq(studentsTable.groupId, lesson.groupId), eq(studentsTable.status, "active")));
  const [attendanceCount] = await db
    .select({ total: count() })
    .from(attendanceTable)
    .where(eq(attendanceTable.lessonId, lesson.id));
  return {
    id: lesson.id,
    groupId: lesson.groupId,
    groupName,
    date: lesson.date,
    topic: lesson.topic,
    isCancelled: lesson.isCancelled,
    cancelReason: lesson.cancelReason,
    studentCount: studentCount.total,
    attendanceMarked: attendanceCount.total > 0,
  };
}

async function getLesson(lessonId: number) {
  const [row] = await db
    .select({ lesson: lessonsTable, groupName: groupsTable.name })
    .from(lessonsTable)
    .innerJoin(groupsTable, eq(lessonsTable.groupId, groupsTable.id))
    .where(eq(lessonsTable.id, lessonId))
    .limit(1);
  return row;
}

router.get("/groups", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  const rows = await db
    .select({ group: groupsTable, teacherName: usersTable.fullName })
    .from(groupsTable)
    .leftJoin(usersTable, eq(groupsTable.teacherId, usersTable.id))
    .where(user.role === "teacher" ? eq(groupsTable.teacherId, user.id) : undefined)
    .orderBy(sql`${groupsTable.isActive} DESC`, groupsTable.name);
  const items = await Promise.all(
    rows.map(async ({ group, teacherName }) => {
      const [students] = await db
        .select({ total: count() })
        .from(studentsTable)
        .where(and(eq(studentsTable.groupId, group.id), eq(studentsTable.status, "active")));
      return {
        id: group.id,
        name: group.name,
        teacherId: group.teacherId,
        teacherName,
        scheduleText: group.scheduleText,
        startDate: group.startDate,
        isActive: group.isActive,
        studentCount: students.total,
      };
    }),
  );
  res.json(ListGroupsResponse.parse(items));
});

router.post("/groups", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  if (!canManage(user)) {
    res.status(403).json({ error: "Guruhni faqat admin boshqaradi." });
    return;
  }
  const parsed = CreateGroupBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (parsed.data.teacherId != null) {
    const [teacher] = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(and(eq(usersTable.id, parsed.data.teacherId), eq(usersTable.role, "teacher"), eq(usersTable.isActive, true)))
      .limit(1);
    if (!teacher) {
      res.status(400).json({ error: "Faol o‘qituvchi topilmadi." });
      return;
    }
  }
  const [created] = await db
    .insert(groupsTable)
    .values({
      ...parsed.data,
      startDate: parsed.data.startDate.toISOString().slice(0, 10),
    })
    .returning();
  if (!created) {
    res.status(500).json({ error: "Guruh yaratilmadi." });
    return;
  }
  const [teacher] = created.teacherId
    ? await db.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, created.teacherId)).limit(1)
    : [];
  const [studentCount] = await db.select({ total: count() }).from(studentsTable).where(eq(studentsTable.groupId, created.id));
  const dto = {
    id: created.id,
    name: created.name,
    teacherId: created.teacherId,
    teacherName: teacher?.fullName ?? null,
    scheduleText: created.scheduleText,
    startDate: created.startDate,
    isActive: created.isActive,
    studentCount: studentCount.total,
  };
  await writeAudit(req, user, "create", "group", created.id, null, dto);
  res.status(201).json(CreateGroupResponse.parse(dto));
});

router.patch("/groups/:groupId", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  if (!canManage(user)) {
    res.status(403).json({ error: "Guruhni faqat admin boshqaradi." });
    return;
  }
  const params = UpdateGroupParams.safeParse(req.params);
  const parsed = UpdateGroupBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: params.error?.message ?? parsed.error?.message ?? "Noto‘g‘ri so‘rov." });
    return;
  }
  const [oldGroup] = await db.select().from(groupsTable).where(eq(groupsTable.id, params.data.groupId)).limit(1);
  if (!oldGroup) {
    res.status(404).json({ error: "Guruh topilmadi." });
    return;
  }
  if (parsed.data.teacherId != null) {
    const [teacher] = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(and(eq(usersTable.id, parsed.data.teacherId), eq(usersTable.role, "teacher"), eq(usersTable.isActive, true)))
      .limit(1);
    if (!teacher) {
      res.status(400).json({ error: "Faol o‘qituvchi topilmadi." });
      return;
    }
  }
  const { startDate, ...groupUpdates } = parsed.data;
  const [updated] = await db
    .update(groupsTable)
    .set({
      ...groupUpdates,
      ...(startDate ? { startDate: startDate.toISOString().slice(0, 10) } : {}),
    })
    .where(eq(groupsTable.id, oldGroup.id))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Guruh topilmadi." });
    return;
  }
  const [teacher] = updated.teacherId
    ? await db.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, updated.teacherId)).limit(1)
    : [];
  const [studentCount] = await db.select({ total: count() }).from(studentsTable).where(eq(studentsTable.groupId, updated.id));
  const dto = {
    id: updated.id,
    name: updated.name,
    teacherId: updated.teacherId,
    teacherName: teacher?.fullName ?? null,
    scheduleText: updated.scheduleText,
    startDate: updated.startDate,
    isActive: updated.isActive,
    studentCount: studentCount.total,
  };
  await writeAudit(req, user, "update", "group", updated.id, oldGroup, updated);
  res.json(UpdateGroupResponse.parse(dto));
});

router.get("/lessons", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  const query = ListLessonsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const conditions = [];
  if (user.role === "teacher") conditions.push(eq(groupsTable.teacherId, user.id));
  if (query.data.groupId) conditions.push(eq(lessonsTable.groupId, query.data.groupId));
  if (query.data.from) conditions.push(gte(lessonsTable.date, query.data.from.toISOString().slice(0, 10)));
  if (query.data.to) conditions.push(lte(lessonsTable.date, query.data.to.toISOString().slice(0, 10)));
  const rows = await db
    .select({ lesson: lessonsTable, groupName: groupsTable.name })
    .from(lessonsTable)
    .innerJoin(groupsTable, eq(lessonsTable.groupId, groupsTable.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(sql`${lessonsTable.date} DESC`, lessonsTable.id);
  const items = await Promise.all(rows.map((row) => lessonDto(row.lesson, row.groupName)));
  res.json(ListLessonsResponse.parse(items));
});

router.post("/lessons", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  if (!canManage(user)) {
    res.status(403).json({ error: "Dars jadvalini faqat admin o‘zgartiradi." });
    return;
  }
  const parsed = CreateLessonBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [group] = await db.select().from(groupsTable).where(eq(groupsTable.id, parsed.data.groupId)).limit(1);
  if (!group || !group.isActive) {
    res.status(400).json({ error: "Faol guruh topilmadi." });
    return;
  }
  const [created] = await db
    .insert(lessonsTable)
    .values({
      ...parsed.data,
      date: parsed.data.date.toISOString().slice(0, 10),
    })
    .returning();
  if (!created) {
    res.status(500).json({ error: "Dars qo‘shilmadi." });
    return;
  }
  const dto = await lessonDto(created, group.name);
  await writeAudit(req, user, "create", "lesson", created.id, null, dto);
  res.status(201).json(CreateLessonResponse.parse(dto));
});

router.get("/lessons/:lessonId/attendance", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  const params = GetLessonAttendanceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const row = await getLesson(params.data.lessonId);
  if (!row) {
    res.status(404).json({ error: "Dars topilmadi." });
    return;
  }
  if (!(await groupAccess(user, row.lesson.groupId))) {
    res.status(403).json({ error: "Bu guruhga ruxsatingiz yo‘q." });
    return;
  }
  const [lesson, roster, marks] = await Promise.all([
    lessonDto(row.lesson, row.groupName),
    db
      .select()
      .from(studentsTable)
      .where(and(eq(studentsTable.groupId, row.lesson.groupId), eq(studentsTable.status, "active")))
      .orderBy(studentsTable.lastName, studentsTable.firstName),
    db.select().from(attendanceTable).where(eq(attendanceTable.lessonId, row.lesson.id)),
  ]);
  const byStudent = new Map(marks.map((mark) => [mark.studentId, mark]));
  const records = roster.map((student) => {
    const mark = byStudent.get(student.id);
    return {
      studentId: student.id,
      studentCode: student.studentCode,
      studentName: `${student.firstName} ${student.lastName}`,
      status: mark?.status ?? null,
      markedAt: mark?.markedAt.toISOString() ?? null,
    };
  });
  res.json(GetLessonAttendanceResponse.parse({ lesson, records }));
});

router.put("/lessons/:lessonId/attendance", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  const params = SaveLessonAttendanceParams.safeParse(req.params);
  const parsed = SaveLessonAttendanceBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: params.error?.message ?? parsed.error?.message ?? "Noto‘g‘ri so‘rov." });
    return;
  }
  const row = await getLesson(params.data.lessonId);
  if (!row) {
    res.status(404).json({ error: "Dars topilmadi." });
    return;
  }
  if (!(await groupAccess(user, row.lesson.groupId))) {
    res.status(403).json({ error: "Bu guruhga ruxsatingiz yo‘q." });
    return;
  }
  if (row.lesson.isCancelled) {
    res.status(400).json({ error: "Bekor qilingan dars uchun davomat belgilanmaydi." });
    return;
  }
  const studentIds = [...new Set(parsed.data.records.map((record) => record.studentId))];
  if (studentIds.length !== parsed.data.records.length) {
    res.status(400).json({ error: "Bir o‘quvchi ikki marta kiritilgan." });
    return;
  }
  const roster = studentIds.length
    ? await db
        .select({ id: studentsTable.id })
        .from(studentsTable)
        .where(
          and(
            eq(studentsTable.groupId, row.lesson.groupId),
            eq(studentsTable.status, "active"),
            inArray(studentsTable.id, studentIds),
          ),
        )
    : [];
  if (roster.length !== studentIds.length) {
    res.status(400).json({ error: "Ro‘yxatda bu guruhga kirmaydigan o‘quvchi bor." });
    return;
  }
  await db.transaction(async (tx) => {
    for (const record of parsed.data.records) {
      await tx
        .insert(attendanceTable)
        .values({
          lessonId: row.lesson.id,
          studentId: record.studentId,
          status: record.status,
          markedBy: user.id,
        })
        .onConflictDoUpdate({
          target: [attendanceTable.lessonId, attendanceTable.studentId],
          set: { status: record.status, markedBy: user.id, markedAt: new Date() },
        });
    }
  });
  await writeAudit(req, user, "update", "attendance", row.lesson.id, null, {
    records: parsed.data.records,
  });
  const fresh = await db.select().from(attendanceTable).where(eq(attendanceTable.lessonId, row.lesson.id));
  const allStudents = await db
    .select()
    .from(studentsTable)
    .where(and(eq(studentsTable.groupId, row.lesson.groupId), eq(studentsTable.status, "active")))
    .orderBy(studentsTable.lastName, studentsTable.firstName);
  const marksByStudent = new Map(fresh.map((mark) => [mark.studentId, mark]));
  const records = allStudents.map((student) => {
    const mark = marksByStudent.get(student.id);
    return {
      studentId: student.id,
      studentCode: student.studentCode,
      studentName: `${student.firstName} ${student.lastName}`,
      status: mark?.status ?? null,
      markedAt: mark?.markedAt.toISOString() ?? null,
    };
  });
  res.json(
    SaveLessonAttendanceResponse.parse({
      lesson: await lessonDto(row.lesson, row.groupName),
      records,
    }),
  );
});

export default router;
