import { Router, type IRouter } from "express";
import { randomInt } from "node:crypto";
import { and, count, eq, gte, ilike, inArray, lte, or, sql } from "drizzle-orm";
import { db, attendanceTable, groupsTable, lessonsTable, studentsTable, usersTable } from "@workspace/db";
import {
  CreateStudentBody,
  CreateStudentResponse,
  GetDashboardResponse,
  ListStudentsQueryParams,
  ListStudentsResponse,
  UpdateStudentBody,
  UpdateStudentParams,
  UpdateStudentResponse,
} from "@workspace/api-zod";
import type { AuthenticatedUser } from "../lib/auth";
import { getAuthenticatedUser } from "../lib/auth";
import { writeAudit } from "../lib/audit";

const router: IRouter = Router();
const PHONE_PATTERN = /^\+?[0-9\s()\-]{7,30}$/;

function attendanceWeight(status: string): number {
  if (status === "present") return 1;
  if (status === "late" || status === "absent_excused") return 0.5;
  return 0;
}

async function teacherGroupIds(user: AuthenticatedUser): Promise<number[] | null> {
  if (user.role !== "teacher") return null;
  const groups = await db.select({ id: groupsTable.id }).from(groupsTable).where(eq(groupsTable.teacherId, user.id));
  return groups.map((group) => group.id);
}

async function attendancePercent(student: typeof studentsTable.$inferSelect): Promise<number> {
  if (!student.groupId) return 0;
  const today = new Date().toISOString().slice(0, 10);
  const scheduledLessons = await db
    .select({ id: lessonsTable.id })
    .from(lessonsTable)
    .where(
      and(
        eq(lessonsTable.groupId, student.groupId),
        eq(lessonsTable.isCancelled, false),
        gte(lessonsTable.date, student.enrolledAt),
        lte(lessonsTable.date, today),
      ),
    );
  if (scheduledLessons.length === 0) return 0;
  const records = await db
    .select({ status: attendanceTable.status })
    .from(attendanceTable)
    .where(
      and(
        eq(attendanceTable.studentId, student.id),
        inArray(attendanceTable.lessonId, scheduledLessons.map((lesson) => lesson.id)),
      ),
    );
  const earned = records.reduce((total, record) => total + attendanceWeight(record.status), 0);
  return Math.round((earned / scheduledLessons.length) * 100);
}

async function studentDto(
  student: typeof studentsTable.$inferSelect,
  groupName: string | null,
) {
  return {
    id: student.id,
    studentCode: student.studentCode,
    firstName: student.firstName,
    lastName: student.lastName,
    phone: student.phone,
    address: student.address,
    status: student.status,
    groupId: student.groupId,
    groupName,
    enrolledAt: student.enrolledAt,
    notes: student.notes,
    attendancePercent: await attendancePercent(student),
    createdAt: student.createdAt.toISOString(),
  };
}

function canManageStudents(user: AuthenticatedUser): boolean {
  return user.role === "super_admin" || user.role === "admin";
}

router.get("/students", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  const query = ListStudentsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const conditions = [];
  const groupIds = await teacherGroupIds(user);
  if (groupIds && groupIds.length === 0) {
    res.json(ListStudentsResponse.parse({ items: [], total: 0, page: 1, pageSize: query.data.pageSize ?? 20 }));
    return;
  }
  if (groupIds) conditions.push(inArray(studentsTable.groupId, groupIds));
  if (query.data.groupId) conditions.push(eq(studentsTable.groupId, query.data.groupId));
  if (query.data.status) conditions.push(eq(studentsTable.status, query.data.status));
  if (query.data.search?.trim()) {
    const term = `%${query.data.search.trim().replaceAll("%", "\\%")}%`;
    conditions.push(
      or(
        ilike(studentsTable.firstName, term),
        ilike(studentsTable.lastName, term),
        ilike(studentsTable.phone, term),
        ilike(studentsTable.studentCode, term),
      )!,
    );
  }
  const where = conditions.length ? and(...conditions) : undefined;
  const page = query.data.page ?? 1;
  const pageSize = query.data.pageSize ?? 20;
  const [totalResult] = await db.select({ total: count() }).from(studentsTable).where(where);
  const rows = await db
    .select({ student: studentsTable, groupName: groupsTable.name })
    .from(studentsTable)
    .leftJoin(groupsTable, eq(studentsTable.groupId, groupsTable.id))
    .where(where)
    .orderBy(sql`${studentsTable.createdAt} DESC`)
    .limit(pageSize)
    .offset((page - 1) * pageSize);
  const items = await Promise.all(rows.map((row) => studentDto(row.student, row.groupName)));
  res.json(ListStudentsResponse.parse({ items, total: totalResult.total, page, pageSize }));
});

router.post("/students", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  if (!canManageStudents(user)) {
    res.status(403).json({ error: "Faqat admin o‘quvchi qo‘sha oladi." });
    return;
  }
  const parsed = CreateStudentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (!PHONE_PATTERN.test(parsed.data.phone.trim())) {
    res.status(400).json({ error: "Telefon raqami formati noto‘g‘ri." });
    return;
  }
  const [duplicate] = await db
    .select({ id: studentsTable.id })
    .from(studentsTable)
    .where(
      and(
        eq(studentsTable.firstName, parsed.data.firstName.trim()),
        eq(studentsTable.lastName, parsed.data.lastName.trim()),
        eq(studentsTable.phone, parsed.data.phone.trim()),
      ),
    )
    .limit(1);
  if (duplicate) {
    res.status(409).json({ error: "Shu ism-familiya va telefon bilan o‘quvchi bor." });
    return;
  }
  if (parsed.data.groupId != null) {
    const [group] = await db.select({ id: groupsTable.id }).from(groupsTable).where(eq(groupsTable.id, parsed.data.groupId)).limit(1);
    if (!group) {
      res.status(400).json({ error: "Tanlangan guruh topilmadi." });
      return;
    }
  }

  let student: typeof studentsTable.$inferSelect | undefined;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const code = String(randomInt(100000, 1000000));
    try {
      [student] = await db
        .insert(studentsTable)
        .values({
          studentCode: code,
          firstName: parsed.data.firstName.trim(),
          lastName: parsed.data.lastName.trim(),
          phone: parsed.data.phone.trim(),
          address: parsed.data.address,
          groupId: parsed.data.groupId,
          enrolledAt: parsed.data.enrolledAt.toISOString().slice(0, 10),
          notes: parsed.data.notes,
          createdBy: user.id,
        })
        .returning();
      break;
    } catch (error) {
      if ((error as { code?: string }).code !== "23505" || attempt === 4) throw error;
    }
  }
  if (!student) {
    res.status(500).json({ error: "O‘quvchi kodi yaratilmadi. Qayta urinib ko‘ring." });
    return;
  }

  const [group] = student.groupId
    ? await db.select({ name: groupsTable.name }).from(groupsTable).where(eq(groupsTable.id, student.groupId)).limit(1)
    : [];
  await writeAudit(req, user, "create", "student", student.id, null, {
    studentCode: student.studentCode,
    firstName: student.firstName,
    lastName: student.lastName,
    groupId: student.groupId,
  });
  res.status(201).json(CreateStudentResponse.parse(await studentDto(student, group?.name ?? null)));
});

router.patch("/students/:studentId", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  if (!canManageStudents(user)) {
    res.status(403).json({ error: "Faqat admin o‘quvchi ma’lumotini o‘zgartira oladi." });
    return;
  }
  const params = UpdateStudentParams.safeParse(req.params);
  const parsed = UpdateStudentBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: params.error?.message ?? parsed.error?.message ?? "Noto‘g‘ri so‘rov." });
    return;
  }
  const [oldStudent] = await db
    .select()
    .from(studentsTable)
    .where(eq(studentsTable.id, params.data.studentId))
    .limit(1);
  if (!oldStudent) {
    res.status(404).json({ error: "O‘quvchi topilmadi." });
    return;
  }
  if (parsed.data.phone !== undefined && !PHONE_PATTERN.test(parsed.data.phone.trim())) {
    res.status(400).json({ error: "Telefon raqami formati noto‘g‘ri." });
    return;
  }
  if (
    parsed.data.firstName !== undefined ||
    parsed.data.lastName !== undefined ||
    parsed.data.phone !== undefined
  ) {
    const firstName = parsed.data.firstName?.trim() ?? oldStudent.firstName;
    const lastName = parsed.data.lastName?.trim() ?? oldStudent.lastName;
    const phone = parsed.data.phone?.trim() ?? oldStudent.phone;
    const [duplicate] = await db
      .select({ id: studentsTable.id })
      .from(studentsTable)
      .where(
        and(
          eq(studentsTable.firstName, firstName),
          eq(studentsTable.lastName, lastName),
          eq(studentsTable.phone, phone),
          sql`${studentsTable.id} <> ${oldStudent.id}`,
        ),
      )
      .limit(1);
    if (duplicate) {
      res.status(409).json({ error: "Shu ism-familiya va telefon bilan o‘quvchi bor." });
      return;
    }
  }
  if (parsed.data.groupId != null) {
    const [group] = await db.select({ id: groupsTable.id }).from(groupsTable).where(eq(groupsTable.id, parsed.data.groupId)).limit(1);
    if (!group) {
      res.status(400).json({ error: "Tanlangan guruh topilmadi." });
      return;
    }
  }
  const statusChanged = parsed.data.status !== undefined && parsed.data.status !== oldStudent.status;
  if (statusChanged && !parsed.data.statusReason?.trim()) {
    res.status(400).json({ error: "Holat o‘zgartirilganda sabab yozilishi shart." });
    return;
  }
  const {
    statusReason,
    enrolledAt,
    ...updates
  } = parsed.data;
  const [updated] = await db
    .update(studentsTable)
    .set({
      ...updates,
      ...(enrolledAt ? { enrolledAt: enrolledAt.toISOString().slice(0, 10) } : {}),
      ...(statusChanged ? { statusReason: statusReason?.trim() ?? null } : {}),
    })
    .where(eq(studentsTable.id, oldStudent.id))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "O‘quvchi topilmadi." });
    return;
  }
  const [group] = updated.groupId
    ? await db.select({ name: groupsTable.name }).from(groupsTable).where(eq(groupsTable.id, updated.groupId)).limit(1)
    : [];
  await writeAudit(req, user, "update", "student", updated.id, oldStudent, updated);
  res.json(UpdateStudentResponse.parse(await studentDto(updated, group?.name ?? null)));
});

router.get("/dashboard", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  const groupIds = await teacherGroupIds(user);
  const groupsWhere = groupIds ? inArray(groupsTable.id, groupIds) : undefined;
  const [activeGroupsResult, teachersResult] = await Promise.all([
    db.select({ total: count() }).from(groupsTable).where(
      groupIds
        ? groupIds.length
          ? and(eq(groupsTable.isActive, true), groupsWhere)
          : sql`false`
        : eq(groupsTable.isActive, true),
    ),
    db.select({ total: count() }).from(usersTable).where(eq(usersTable.role, "teacher")),
  ]);
  const allowedGroups = await db
    .select({ id: groupsTable.id })
    .from(groupsTable)
    .where(groupIds ? (groupIds.length ? inArray(groupsTable.id, groupIds) : sql`false`) : undefined);
  const allowedGroupIds = allowedGroups.map((group) => group.id);
  const activeStudentsQuery = db
    .select({ total: count() })
    .from(studentsTable)
    .where(
      and(
        eq(studentsTable.status, "active"),
        groupIds
          ? allowedGroupIds.length
            ? inArray(studentsTable.groupId, allowedGroupIds)
            : sql`false`
          : undefined,
      ),
    );
  const [activeStudentsResult] = await activeStudentsQuery;
  const today = new Date().toISOString().slice(0, 10);
  const todayLessonsRaw = allowedGroupIds.length
    ? await db
        .select({ lesson: lessonsTable, groupName: groupsTable.name })
        .from(lessonsTable)
        .innerJoin(groupsTable, eq(lessonsTable.groupId, groupsTable.id))
        .where(and(eq(lessonsTable.date, today), inArray(lessonsTable.groupId, allowedGroupIds)))
        .orderBy(lessonsTable.id)
    : [];
  const todayLessonIds = todayLessonsRaw.map((row) => row.lesson.id);
  const todayRecords = todayLessonIds.length
    ? await db.select().from(attendanceTable).where(inArray(attendanceTable.lessonId, todayLessonIds))
    : [];
  const todayAttendancePercent =
    todayRecords.length === 0
      ? 0
      : Math.round(
          (todayRecords.reduce((total, record) => total + attendanceWeight(record.status), 0) /
            todayRecords.length) *
            100,
        );
  const recentRows = await db
    .select({ student: studentsTable, groupName: groupsTable.name })
    .from(studentsTable)
    .leftJoin(groupsTable, eq(studentsTable.groupId, groupsTable.id))
    .where(
      allowedGroupIds.length
        ? inArray(studentsTable.groupId, allowedGroupIds)
        : groupIds
          ? sql`false`
          : undefined,
    )
    .orderBy(sql`${studentsTable.createdAt} DESC`)
    .limit(5);
  const recentStudents = await Promise.all(recentRows.map((row) => studentDto(row.student, row.groupName)));
  const attendanceTrend = await Promise.all(
    Array.from({ length: 7 }, async (_, offset) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - offset));
      const dateKey = date.toISOString().slice(0, 10);
      const dayLessons = allowedGroupIds.length
        ? await db
            .select({ id: lessonsTable.id })
            .from(lessonsTable)
            .where(
              and(
                eq(lessonsTable.date, dateKey),
                eq(lessonsTable.isCancelled, false),
                inArray(lessonsTable.groupId, allowedGroupIds),
              ),
            )
        : [];
      const rows = dayLessons.length
        ? await db
            .select({ status: attendanceTable.status })
            .from(attendanceTable)
            .where(inArray(attendanceTable.lessonId, dayLessons.map((lesson) => lesson.id)))
        : [];
      const percent = rows.length
        ? Math.round((rows.reduce((total, row) => total + attendanceWeight(row.status), 0) / rows.length) * 100)
        : 0;
      return { date: dateKey, percent };
    }),
  );
  const todayLessonsList = await Promise.all(
    todayLessonsRaw.map(async ({ lesson, groupName }) => {
      const [studentCount] = await db
        .select({ total: count() })
        .from(studentsTable)
        .where(and(eq(studentsTable.groupId, lesson.groupId), eq(studentsTable.status, "active")));
      const marked = todayRecords.some((record) => record.lessonId === lesson.id);
      return {
        id: lesson.id,
        groupId: lesson.groupId,
        groupName,
        date: lesson.date,
        topic: lesson.topic,
        isCancelled: lesson.isCancelled,
        cancelReason: lesson.cancelReason,
        studentCount: studentCount.total,
        attendanceMarked: marked,
      };
    }),
  );
  res.json(
    GetDashboardResponse.parse({
      activeStudents: activeStudentsResult.total,
      activeGroups: activeGroupsResult[0]?.total ?? 0,
      teachers: user.role === "teacher" ? 1 : (teachersResult[0]?.total ?? 0),
      todayLessons: todayLessonsRaw.length,
      todayAttendancePercent,
      attendanceTrend,
      recentStudents,
      todayLessonsList,
    }),
  );
});

export default router;
