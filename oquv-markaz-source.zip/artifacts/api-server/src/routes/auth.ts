import { Router, type IRouter } from "express";
import bcrypt from "bcryptjs";
import { and, count, eq, gt, sql } from "drizzle-orm";
import { db, loginAttemptsTable, sessionsTable, usersTable } from "@workspace/db";
import {
  BootstrapAdminBody,
  BootstrapAdminResponse,
  GetCurrentUserResponse,
  GetSetupStatusResponse,
  LoginBody,
  LoginResponse,
} from "@workspace/api-zod";
import {
  clearSessionCookie,
  getAuthenticatedUser,
  getCookieValue,
  hashSessionToken,
  newSessionToken,
  requestIp,
  SESSION_COOKIE,
  SESSION_DURATION_MS,
  sessionUser,
  setSessionCookie,
} from "../lib/auth";
import { writeAudit } from "../lib/audit";

const router: IRouter = Router();
const PASSWORD_POLICY = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,128}$/;

router.get("/auth/setup-status", async (_req, res): Promise<void> => {
  const [result] = await db.select({ total: count() }).from(usersTable);
  res.json(GetSetupStatusResponse.parse({ needsBootstrap: result.total === 0 }));
});

router.post("/auth/bootstrap", async (req, res): Promise<void> => {
  const parsed = BootstrapAdminBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (!PASSWORD_POLICY.test(parsed.data.password)) {
    res.status(400).json({ error: "Parolda katta-kichik harf va raqam bo‘lishi kerak." });
    return;
  }

  const login = parsed.data.login.trim().toLowerCase();
  const passwordHash = await bcrypt.hash(parsed.data.password, 12);
  const token = newSessionToken();
  const tokenHash = hashSessionToken(token);
  const expiresAt = new Date(Date.now() + SESSION_DURATION_MS);
  let created: typeof usersTable.$inferSelect;
  try {
    created = await db.transaction(async (tx) => {
      await tx.execute(sql`SELECT pg_advisory_xact_lock(739201)`);
      const [existing] = await tx.select({ total: count() }).from(usersTable);
      if (existing.total > 0) {
        throw new Error("BOOTSTRAP_COMPLETE");
      }
      const [user] = await tx
        .insert(usersTable)
        .values({
          role: "super_admin",
          login,
          passwordHash,
          fullName: parsed.data.fullName.trim(),
        })
        .returning();
      if (!user) throw new Error("ADMIN_CREATE_FAILED");
      await tx.insert(sessionsTable).values({
        userId: user.id,
        refreshTokenHash: tokenHash,
        ip: requestIp(req),
        userAgent: req.get("user-agent") ?? null,
        expiresAt,
      });
      return user;
    });
  } catch (error) {
    if (error instanceof Error && error.message === "BOOTSTRAP_COMPLETE") {
      res.status(409).json({ error: "Tizim boshlang‘ich sozlamadan o‘tgan." });
      return;
    }
    if ((error as { code?: string }).code === "23505") {
      res.status(409).json({ error: "Bu login allaqachon ishlatilgan." });
      return;
    }
    throw error;
  }

  await writeAudit(req, created, "create", "user", created.id, null, {
    role: created.role,
    login: created.login,
    fullName: created.fullName,
  });
  setSessionCookie(res, token);
  res.status(201).json(BootstrapAdminResponse.parse(sessionUser(created)));
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const login = parsed.data.login.trim().toLowerCase();
  const ip = requestIp(req);
  const since = new Date(Date.now() - 15 * 60 * 1000);
  const [recentFailures] = await db
    .select({ total: count() })
    .from(loginAttemptsTable)
    .where(
      and(
        eq(loginAttemptsTable.login, login),
        eq(loginAttemptsTable.ip, ip),
        eq(loginAttemptsTable.success, false),
        gt(loginAttemptsTable.createdAt, since),
      ),
    );
  if (recentFailures.total >= 5) {
    res.status(429).json({ error: "Kirish vaqtincha bloklangan. 15 daqiqadan so‘ng urinib ko‘ring." });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.login, login)).limit(1);
  const valid = Boolean(
    user?.isActive && (await bcrypt.compare(parsed.data.password, user.passwordHash)),
  );
  await db.insert(loginAttemptsTable).values({ login, ip, success: valid });
  if (!valid || !user) {
    res.status(401).json({ error: "Login yoki parol noto‘g‘ri." });
    return;
  }

  const token = newSessionToken();
  const now = new Date();
  await db.transaction(async (tx) => {
    await tx.update(usersTable).set({ lastLoginAt: now }).where(eq(usersTable.id, user.id));
    await tx.insert(sessionsTable).values({
      userId: user.id,
      refreshTokenHash: hashSessionToken(token),
      ip,
      userAgent: req.get("user-agent") ?? null,
      expiresAt: new Date(now.getTime() + SESSION_DURATION_MS),
    });
  });
  setSessionCookie(res, token);
  res.json(LoginResponse.parse(sessionUser({ ...user, lastLoginAt: now })));
});

router.get("/auth/me", async (req, res): Promise<void> => {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: "Tizimga kiring." });
    return;
  }
  res.json(GetCurrentUserResponse.parse(sessionUser(user)));
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  const token = getCookieValue(req, SESSION_COOKIE);
  if (token) {
    await db.delete(sessionsTable).where(eq(sessionsTable.refreshTokenHash, hashSessionToken(token)));
  }
  clearSessionCookie(res);
  res.sendStatus(204);
});

export default router;
