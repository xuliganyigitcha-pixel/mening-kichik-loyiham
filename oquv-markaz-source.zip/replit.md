# O‘quv Markaz

O‘quv markazlar uchun o‘quvchilar, xodimlar, guruhlar, darslar va davomatni boshqarish tizimi.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/oquv-markaz` — Uzbek-language React web app and staff workflows.
- `artifacts/api-server/src/routes` — backend API routes.
- `lib/api-spec/openapi.yaml` — API contract source of truth; regenerate clients after changes.
- `lib/db/src/schema` — PostgreSQL schema definitions.

## Architecture decisions

- Staff access uses a server-managed, hashed session cookie; authorization is enforced in API routes.
- Student records are retained and their status is changed rather than deleting the record.
- Student codes are generated once, stored uniquely, and are not editable through normal student updates.
- The initial product slice covers staff setup, students, groups, lessons, and attendance. Payments and Telegram notifications remain later modules.

## Product

Super admins create the first account during setup, then manage staff access. Admins manage student records, groups, schedules, and staff; teachers work with their assigned groups and record attendance. Dashboard, student, group, lesson, and attendance data persist in PostgreSQL.

## User preferences

The interface and user-facing copy are in Uzbek.

## Gotchas

- New API request/response changes start in `lib/api-spec/openapi.yaml`; run `pnpm --filter @workspace/api-spec run codegen` afterward.
- Calendar dates are strings in PostgreSQL and converted at the API boundary from generated Zod date inputs.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
